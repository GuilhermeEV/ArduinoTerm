$(document).ready(function() {

  var active1 = false;
  var active2 = false;
  var active3 = false;
  var active4 = false;

    $('.parent2').on('mousedown touchstart', function() {
    
    if (!active1) $(this).find('.test1').css({'background-color': 'gray', 'transform': 'translate(0px,125px)'});
    else $(this).find('.test1').css({'background-color': 'dimGray', 'transform': 'none'}); 
     if (!active2) $(this).find('.test2').css({'background-color': 'gray', 'transform': 'translate(60px,105px)'});
    else $(this).find('.test2').css({'background-color': 'darkGray', 'transform': 'none'});
      if (!active3) $(this).find('.test3').css({'background-color': 'gray', 'transform': 'translate(105px,60px)'});
    else $(this).find('.test3').css({'background-color': 'silver', 'transform': 'none'});
      if (!active4) $(this).find('.test4').css({'background-color': 'gray', 'transform': 'translate(125px,0px)'});
    else $(this).find('.test4').css({'background-color': 'silver', 'transform': 'none'});
    active1 = !active1;
    active2 = !active2;
    active3 = !active3;
    active4 = !active4;
      
    });


    $(".test1").on("click", function(){
      $("#animacao").css("display", "none")
      $("#projetos").css("display", "none")
      $("#downloads").css("display", "none")
      $("#grupo").css("display", "block")
    })
    $(".test2").on("click", function(){
      $("#grupo").css("display", "none")
      $("#projetos").css("display", "none")
      $("#downloads").css("display", "none")
      $("#animacao").css("display", "block")
    })
    $(".test3").on("click", function(){
      $("#grupo").css("display", "none")
      $("#animacao").css("display", "none")
      $("#downloads").css("display", "none")
      $("#projetos").css("display", "block")
    })
    $(".test4").on("click", function(){
      $("#grupo").css("display", "none")
      $("#animacao").css("display", "none")
      $("#projetos").css("display", "none")
      $("#downloads").css("display", "block")
    })
// Themes begin
am4core.useTheme(am4themes_spiritedaway);
// Themes end

// create chart
var chart = am4core.create("chartdiv", am4charts.GaugeChart);
chart.hiddenState.properties.opacity = 0; // this makes initial fade in effect

chart.innerRadius = -25;

var axis = chart.xAxes.push(new am4charts.ValueAxis());
axis.min = 15;
axis.max = 30;
axis.strictMinMax = true;
axis.renderer.grid.template.stroke = new am4core.InterfaceColorSet().getFor("background");
axis.renderer.grid.template.strokeOpacity = 0.3;

var colorSet = new am4core.ColorSet();

var range0 = axis.axisRanges.create();
range0.value = 15;
range0.endValue = 20;
range0.axisFill.fillOpacity = 1;
range0.axisFill.fill = am4core.color("#00BFFF");
range0.axisFill.zIndex = - 1;

var range1 = axis.axisRanges.create();
range1.value = 20;
range1.endValue = 25;
range1.axisFill.fillOpacity = 1;
range1.axisFill.fill = am4core.color("#FFD700");
range1.axisFill.zIndex = -1;

var range2 = axis.axisRanges.create();
range2.value = 25;
range2.endValue = 30;
range2.axisFill.fillOpacity = 1;
range2.axisFill.fill = am4core.color("#FF4500");
range2.axisFill.zIndex = -1;

var hand = chart.hands.push(new am4charts.ClockHand());

// using chart.setTimeout method as the timeout will be disposed together with a chart
chart.setTimeout(randomValue, 2000);

function randomValue() {
    //hand.showValue(Math.random() * 100, 1000, am4core.ease.cubicOut);

    $.ajax({
      type: "GET",
      url: "http://10.161.103.20:3000/api",
      success: function(retorno){
        debugger;
        hand.showValue(parseFloat(retorno), 250, am4core.ease.cubicOut);
        
      }
    })
    chart.setTimeout(randomValue, 500);
}
  
  

});